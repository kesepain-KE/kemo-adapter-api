"""Pinned Kemo protocol artifact package."""
