"""Namespace for the Kemo protocol artifact."""
